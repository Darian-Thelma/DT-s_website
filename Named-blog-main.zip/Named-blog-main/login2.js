document.getElementById('nav-login-form').addEventListener('submit', function(e) {
  e.preventDefault();
  // Example: Show alert for navbar login
  alert('Navbar Sign In clicked!');
});

document.getElementById('signup-form').addEventListener('submit', function(e) {
  e.preventDefault();
  const username = document.getElementById('signup-username').value;
  const email = document.getElementById('signup-email').value;
  const password = document.getElementById('signup-password').value;
  const confirm = document.getElementById('signup-confirm').value;
  const message = document.getElementById('signup-message');

  if (!username || !email || !password || !confirm) {
    message.textContent = "Please fill in all fields.";
    return;
  }
  if (password !== confirm) {
    message.textContent = "Passwords do not match.";
    return;
  }
  message.style.color = "green";
  message.textContent = "Signup successful!";
});